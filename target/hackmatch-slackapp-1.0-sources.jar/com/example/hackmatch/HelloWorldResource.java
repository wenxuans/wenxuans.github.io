package com.example.hackmatch;

//import com.example.hackmatch.Greeting;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.Consumes;

@Path("/hello")
@Produces(MediaType.TEXT_HTML)
@Consumes(MediaType.APPLICATION_JSON)
public class HelloWorldResource {

    public HelloWorldResource() {
	
    }
    @GET
    public Greeting sayHello() {
	return new Greeting();
    }
}
